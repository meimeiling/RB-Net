clc
clear
close all
addpath(genpath(pwd));
Load the data


[Z_VBM,Z_FDG]=ADE(VBM',FDG'); 
%[Z_VBM,Z_AV]=ADE(VBM',AV'); 
 [Z_VBM,W_VBM]=RB-Net(Z_VBM);
 [Z_FDG,W_FDG]=RB-Net(Z_FDG);
% [Z_AV,W_AV]=RB-Net(Z_AV);


W=W_VBM;