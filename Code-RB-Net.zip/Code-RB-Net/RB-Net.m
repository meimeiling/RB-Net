function [Z,W]=RB-Net(X)
% %         X=X';
%
% clc;clear all;close all;
% X=randn(100, 220);
[M,N]=size(X);

%%%%��ʼ��
lambda_1=1;
lambda_2=0.1;%0.1
lambda_3=1;%1
R=4;
gamma_R=0.01;
gamma_W=0.0001;
W=0.01*ones(N,N);
P=X*W;
max_iteration=20000;
for iter=1:max_iteration
    iter
%%%%%%����R
XW_norm=[];
for i=1:N
    XW_norm=[XW_norm norm(X*W(:,i),2)];
end
Gradient_R=-(lambda_3/N)*sum(XW_norm-R,2);
R_new=R-gamma_R*Gradient_R;
   

%%%%%%����W
for i=1:N
    Gradient_Wi=lambda_1*X'*(X*W(:,i)-X(:,i))+lambda_2*W(:,i)+(lambda_3/N)*(1-R/norm(X*W(:,i),2))*((X*W(:,i))'*X)';
    W_new(:,i)=W(:,i)-gamma_W*Gradient_Wi;
end
     RR=(norm(R-R_new,2)/norm(R_new,2))^2;
     
    if RR<1e-8
        break;
    end
     W=W_new;
     R=R_new;
 %%%%%%%%��������
 SUM=0;
 for i=1:N
 TT=(norm(X*W(:,i),2)-R)^2;
 SUM=SUM+TT;
 end
CC(iter)=lambda_1*norm(X-X*W,'fro')^2+lambda_2*norm(W,'fro')^2+(lambda_3/N)*SUM;
    kk(iter)=iter;
end

Z=(X*W)';
% 
% figure;
% plot(kk,CC,'LineWidth',4);
% hold on;
% plot(kk,CC,'.','Markersize',20);
% set(gca, 'Fontname', 'Times New Roman','FontSize',17);
% set(gca,'XLim',[1 iter]);
% %set(gca,'Fontname','Monospaced','FontSize',17);
% xlabel('\fontname{����}\fontsize{17}��������');
% %ylabel('||{\bf C}||_2 ');
% %ylabel('$\it We$�仯��','Interpreter','latex');
% ylabel('\fontname{Times New Roman}\fontsize{17}{\it{We}}\fontname{����}\fontsize{17}�ı仯��');


